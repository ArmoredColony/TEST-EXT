import bpy
import os

def _get_manifest_version():
    manifest_path = os.path.join(os.path.dirname(__file__), "blender_manifest.toml")
    try:
        import tomllib  # Python 3.11+ (Blender 4.2+) has this
        with open(manifest_path, "rb") as f:
            data = tomllib.load(f)
        return data.get("version", "unknown")
    except Exception:
        return "unknown"

def draw_statusbar(self, context):
    layout = self.layout
    version = _get_manifest_version()
    layout.separator_spacer()
    layout.label(text=f"TEST-EXT v{version}")

def register():
    bpy.types.STATUSBAR_HT_header.append(draw_statusbar)

def unregister():
    bpy.types.STATUSBAR_HT_header.remove(draw_statusbar)
